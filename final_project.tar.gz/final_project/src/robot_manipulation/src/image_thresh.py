import numpy as np
import matplotlib.pyplot as plt

def main(canny_img):
    THRESH_LIMIT = 1
    img = np.copy(canny_img)
    print(img)
    img[img < THRESH_LIMIT] = 0
    img[img >= THRESH_LIMIT] = 1

    thresholdLimit = True
    while thresholdLimit:
        plt.imshow(img, interpolation='nearest')
        plt.show()
        user_choice = input("Is this fine to draw? (Press y or the new thresh limit) (This is ignoring all the points with value < " + str(THRESH_LIMIT) +  ")\n")
        if user_choice == 'y':
            thresholdLimit = False
        else:
            THRESH_LIMIT = int(user_choice)
            img = np.copy(canny_img)
            img[img < THRESH_LIMIT] = 0
            img[img >= THRESH_LIMIT] = 1
    return img