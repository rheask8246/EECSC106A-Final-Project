import numpy as np

def threshold_image(img, thresh):
    # shape = img.shape
    # img = img.reshape((1, -1))
    # img[img > thresh] = 1
    # img[img <= thresh] = 0
    # return img.reshape(shape)
    for row in range(img.shape[0]):
        for col in range(img.shape[1]):
            if img[row, col] > thresh:
                img[row, col] = 1
            else:
                img[row, col] = 0
    return img